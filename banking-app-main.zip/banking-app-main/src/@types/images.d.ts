declare module '*.jpeg' {
  const value: any;
  export = value;
}
