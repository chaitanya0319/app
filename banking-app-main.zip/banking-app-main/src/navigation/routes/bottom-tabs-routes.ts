export enum BottomTabsRoutes {
  Cards = 'Cards',
  Home = 'Home',
  Settings = 'Settings',
}
