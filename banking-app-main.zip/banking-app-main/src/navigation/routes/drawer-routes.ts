export enum DrawerRoutes {
  HomeStack = 'HomeStack',
  CardsTabs = 'CardsTabs',
  SettingsTabs = 'SettingsTabs',
}
